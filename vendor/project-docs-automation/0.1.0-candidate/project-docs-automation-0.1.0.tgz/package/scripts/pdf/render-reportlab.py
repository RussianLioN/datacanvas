#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import json
import re
import sys
from io import BytesIO
from pathlib import Path
from typing import Any


PRIVATE_METADATA_PATTERNS = [
    re.compile(r"/Users/[^\s)<>\"']+"),
    re.compile(r"/home/[^\s)<>\"']+"),
    re.compile(r"/(?:tmp|private/tmp|var/folders|Volumes)/[^\s)<>\"']+"),
    re.compile(r"\bfile://[^\s)<>\"']+", re.IGNORECASE),
    re.compile(r"[A-Za-z]:\\Users\\[^\s)<>\"']+"),
    re.compile(r"\b(?:password|secret|token|credential)s?\b\s*[:=]", re.IGNORECASE),
]
EXTERNAL_ACTIONS = {"/URI", "/Launch", "/GoToR", "/SubmitForm", "/ImportData", "/Rendition", "/Movie", "/Sound"}


class PdfProviderError(Exception):
    pass


def fail(message: str) -> None:
    print(json.dumps({"ok": False, "error": message}, ensure_ascii=False))
    raise SystemExit(1)


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def normalize_extracted_text(value: str) -> str:
    return "\n".join(line.rstrip() for line in value.replace("\r\n", "\n").replace("\r", "\n").split("\n")).strip() + "\n"


def load_payload() -> dict[str, Any]:
    try:
        payload = json.loads(sys.stdin.read())
    except json.JSONDecodeError as error:
        raise PdfProviderError(f"PDF не создан: вход поставщика не является JSON: {error.msg}.") from error
    if not isinstance(payload, dict):
        raise PdfProviderError("PDF не создан: вход поставщика должен быть объектом.")
    return payload


def verify_font(font: dict[str, Any]) -> tuple[str, str]:
    font_path = font.get("path")
    expected_sha = font.get("sha256")
    if not isinstance(font_path, str) or len(font_path) == 0:
        raise PdfProviderError("PDF не создан: путь к шрифту не задан.")
    if not isinstance(expected_sha, str) or not re.fullmatch(r"[a-f0-9]{64}", expected_sha):
        raise PdfProviderError("PDF не создан: SHA-256 шрифта недействителен.")

    path = Path(font_path)
    if not path.is_file():
        raise PdfProviderError("PDF не создан: заданный шрифт не найден.")
    actual_sha = sha256_bytes(path.read_bytes())
    if actual_sha != expected_sha:
        raise PdfProviderError("PDF не создан: SHA-256 шрифта не совпадает.")
    return str(path), actual_sha


def import_pdf_packages() -> tuple[Any, Any, Any, Any, dict[str, str]]:
    try:
        import pdfplumber
        import pypdf
        import reportlab
        from pypdf import PdfReader
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfgen.canvas import Canvas
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.utils import simpleSplit
    except ImportError as error:
        raise PdfProviderError(f"PDF не создан: Python-пакеты ReportLab, pdfplumber или pypdf недоступны: {error.name}.") from error

    packages = {
        "reportlab": str(reportlab.Version),
        "pdfplumber": str(pdfplumber.__version__),
        "pypdf": str(pypdf.__version__),
    }
    return (pdfplumber, PdfReader, pdfmetrics, TTFont, {"Canvas": Canvas, "letter": letter, "simpleSplit": simpleSplit, **packages})


def safe_text(value: Any) -> str:
    if not isinstance(value, str) or len(value) == 0:
        raise PdfProviderError("PDF не создан: текстовый блок содержит пустой или неверный текст.")
    return value


def output_blocks(input_document: dict[str, Any], blocks: list[Any]) -> list[Any]:
    first_block = blocks[0] if blocks else None
    title = safe_text(input_document.get("title")).strip()
    if (
        isinstance(first_block, dict)
        and first_block.get("type") == "heading"
        and first_block.get("level") == 1
        and isinstance(first_block.get("text"), str)
        and first_block.get("text", "").strip() == title
    ):
        return blocks[1:]
    return blocks


def split_lines(text: str, width: float, font_name: str, size: int, simple_split: Any) -> list[str]:
    lines = simple_split(text, font_name, size, width)
    return lines if len(lines) > 0 else [text]


def render_pdf(payload: dict[str, Any], font_path: str, font_sha: str, packages: tuple[Any, Any, Any, Any, dict[str, Any]]) -> tuple[bytes, dict[str, Any]]:
    _pdfplumber, _reader, pdfmetrics, tt_font, reportlab_tools = packages
    input_document = payload.get("input")
    template = payload.get("template")
    if not isinstance(input_document, dict) or not isinstance(template, dict):
        raise PdfProviderError("PDF не создан: вход или шаблон отсутствуют.")
    if template.get("requiredEngine") != "ReportLab":
        raise PdfProviderError("PDF не создан: шаблон требует другой движок.")
    if template.get("fixedMetadataTimestamp") != "2000-01-01T00:00:00Z":
        raise PdfProviderError("PDF не создан: шаблон не фиксирует метаданные.")

    document = input_document.get("document")
    blocks = document.get("blocks") if isinstance(document, dict) else None
    if not isinstance(blocks, list) or len(blocks) == 0:
        raise PdfProviderError("PDF не создан: структурированный документ пуст.")
    blocks = output_blocks(input_document, blocks)

    font_name = "PDAEmbeddedFont"
    pdfmetrics.registerFont(tt_font(font_name, font_path))

    canvas_factory = reportlab_tools["Canvas"]
    page_width, page_height = reportlab_tools["letter"]
    simple_split = reportlab_tools["simpleSplit"]
    margin = float(template.get("marginsPoints", 72))
    usable_width = page_width - margin * 2
    output = BytesIO()
    canvas = canvas_factory(output, pagesize=(page_width, page_height), pageCompression=0, invariant=1, pdfVersion=(1, 7), lang="ru-RU")
    canvas.setTitle(safe_text(input_document.get("title")))
    canvas.setAuthor("project-docs-automation")
    canvas.setCreator("project-docs-automation ReportLab provider")
    canvas.setSubject("neutral-pdf-business-brief-v1")
    canvas.setKeywords("")

    y = page_height - margin
    page_number = 1
    geometry = {
        "pageWidthPoints": page_width,
        "pageHeightPoints": page_height,
        "marginPoints": margin,
        "elementCount": 0,
        "minBottomY": page_height,
        "overflowCount": 0,
        "rowOverlapCount": 0,
    }
    previous_table_bottom_by_page: dict[int, float] = {}

    def record_element(bottom_y: float) -> None:
        geometry["elementCount"] += 1
        geometry["minBottomY"] = min(geometry["minBottomY"], bottom_y)
        if bottom_y < margin:
            geometry["overflowCount"] += 1

    def new_page() -> None:
        nonlocal y, page_number
        canvas.showPage()
        page_number += 1
        y = page_height - margin

    def ensure_space(required: float) -> None:
        if y - required < margin:
            new_page()

    def draw_text_lines(text: str, x: float, width: float, size: int, leading: int, after: int = 0) -> None:
        nonlocal y
        canvas.setFont(font_name, size)
        for line in split_lines(text, width, font_name, size, simple_split):
            ensure_space(leading)
            canvas.setFont(font_name, size)
            canvas.drawString(x, y, line)
            record_element(y - size)
            y -= leading
        y -= after

    draw_text_lines(safe_text(input_document.get("title")), margin, usable_width, 20, 24, 10)

    for block in blocks:
        if not isinstance(block, dict):
            raise PdfProviderError("PDF не создан: блок документа должен быть объектом.")
        block_type = block.get("type")
        if block_type == "heading":
            level = int(block.get("level", 2))
            size = 18 if level == 1 else 15 if level == 2 else 13
            draw_text_lines(safe_text(block.get("text")), margin, usable_width, size, size + 4, 8)
        elif block_type == "paragraph":
            draw_text_lines(safe_text(block.get("text")), margin, usable_width, 11, 15, 8)
        elif block_type == "note":
            ensure_space(24)
            canvas.setStrokeColorRGB(0.5, 0.5, 0.5)
            canvas.line(margin, y + 4, margin + usable_width, y + 4)
            y -= 10
            draw_text_lines(safe_text(block.get("text")), margin, usable_width, 10, 14, 6)
        elif block_type in {"unorderedList", "orderedList"}:
            items = block.get("items")
            if not isinstance(items, list) or len(items) == 0:
                raise PdfProviderError("PDF не создан: список документа пуст.")
            for index, item in enumerate(items, start=1):
                item_lines = split_lines(safe_text(item), usable_width - 22, font_name, 11, simple_split)
                marker = "-" if block_type == "unorderedList" else f"{index}."
                for line_index, line in enumerate(item_lines):
                    ensure_space(15)
                    canvas.setFont(font_name, 11)
                    if line_index == 0:
                        canvas.drawString(margin, y, marker)
                        record_element(y - 11)
                    canvas.drawString(margin + 22, y, line)
                    record_element(y - 11)
                    y -= 15
            y -= 6
        elif block_type == "table":
            headers = block.get("headers")
            rows = block.get("rows")
            if not isinstance(headers, list) or not isinstance(rows, list) or len(headers) == 0 or len(rows) == 0:
                raise PdfProviderError("PDF не создан: таблица документа пуста.")
            column_width = usable_width / len(headers)
            table_rows = [headers, *rows]
            for row_index, row in enumerate(table_rows):
                if not isinstance(row, list) or len(row) != len(headers):
                    raise PdfProviderError("PDF не создан: ширина строки таблицы не совпадает с заголовком.")
                size = 9 if row_index == 0 else 8
                leading = 11 if row_index == 0 else 10
                padding = 5
                row_lines = [split_lines(safe_text(cell), column_width - 8, font_name, size, simple_split) for cell in row]
                max_body_lines = max(1, int((page_height - margin * 2 - padding * 2) // leading))
                consumed = 0
                max_lines = max(len(lines) for lines in row_lines)
                while consumed < max_lines:
                    remaining_height = y - margin - padding * 2
                    available_lines = int(remaining_height // leading)
                    if available_lines <= 0:
                        new_page()
                        available_lines = max_body_lines
                    chunk_lines = min(max_lines - consumed, max(1, min(available_lines, max_body_lines)))
                    row_height = chunk_lines * leading + padding * 2
                    ensure_space(row_height)
                    row_top = y
                    row_bottom = y - row_height
                    previous_bottom = previous_table_bottom_by_page.get(page_number)
                    if previous_bottom is not None and row_top > previous_bottom:
                        geometry["rowOverlapCount"] += 1
                    previous_table_bottom_by_page[page_number] = row_bottom
                    x = margin
                    for cell_lines in row_lines:
                        canvas.rect(x, row_bottom, column_width, row_height, stroke=1, fill=0)
                        record_element(row_bottom)
                        canvas.setFont(font_name, size)
                        text_y = row_top - padding - size
                        for line in cell_lines[consumed:consumed + chunk_lines]:
                            canvas.drawString(x + 4, text_y, line)
                            record_element(text_y - size)
                            text_y -= leading
                        x += column_width
                    y = row_bottom
                    consumed += chunk_lines
            y -= 8
        else:
            raise PdfProviderError(f"PDF не создан: неизвестный тип блока {block_type}.")

    canvas.save()
    pdf_bytes = output.getvalue()
    if sha256_bytes(Path(font_path).read_bytes()) != font_sha:
        raise PdfProviderError("PDF не создан: SHA-256 шрифта изменился во время генерации.")
    if geometry["elementCount"] == 0:
        geometry["minBottomY"] = page_height - margin
    return pdf_bytes, geometry


def indirect_value(value: Any) -> Any:
    try:
        return value.get_object()
    except Exception:
        return value


def count_pdf_risks(value: Any, seen: set[int] | None = None) -> dict[str, int]:
    if seen is None:
        seen = set()
    obj = indirect_value(value)
    obj_id = id(obj)
    if obj_id in seen:
        return {"javascript": 0, "external": 0, "attachments": 0}
    seen.add(obj_id)

    counts = {"javascript": 0, "external": 0, "attachments": 0}
    if isinstance(obj, dict):
        action = str(obj.get("/S", ""))
        if action == "/JavaScript" or "/JS" in obj:
            counts["javascript"] += 1
        if action in EXTERNAL_ACTIONS:
            counts["external"] += 1
        if "/EmbeddedFiles" in obj or str(obj.get("/Subtype", "")) == "/FileAttachment":
            counts["attachments"] += 1
        for child in obj.values():
            child_counts = count_pdf_risks(child, seen)
            for key in counts:
                counts[key] += child_counts[key]
    elif isinstance(obj, (list, tuple)):
        for child in obj:
            child_counts = count_pdf_risks(child, seen)
            for key in counts:
                counts[key] += child_counts[key]
    return counts


def inspect_embedded_fonts(reader: Any) -> dict[str, Any]:
    descriptor_count = 0
    file_count = 0
    embedded_stream_hashes: list[str] = []
    subtype = "missing"
    seen_fonts: set[int] = set()

    for page in reader.pages:
        resources = indirect_value(page.get("/Resources", {}))
        fonts = indirect_value(resources.get("/Font", {})) if isinstance(resources, dict) else {}
        if not isinstance(fonts, dict):
            continue
        for font_ref in fonts.values():
            font = indirect_value(font_ref)
            font_id = id(font)
            if font_id in seen_fonts or not isinstance(font, dict):
                continue
            seen_fonts.add(font_id)
            descriptor = indirect_value(font.get("/FontDescriptor"))
            if not isinstance(descriptor, dict):
                descendant_fonts = indirect_value(font.get("/DescendantFonts", []))
                if isinstance(descendant_fonts, list):
                    for descendant in descendant_fonts:
                        descendant_object = indirect_value(descendant)
                        if isinstance(descendant_object, dict):
                            descriptor = indirect_value(descendant_object.get("/FontDescriptor"))
                            if isinstance(descriptor, dict):
                                break
            if not isinstance(descriptor, dict):
                continue
            descriptor_count += 1
            for candidate in ("/FontFile2", "/FontFile3"):
                stream = indirect_value(descriptor.get(candidate))
                if stream is None:
                    continue
                try:
                    stream_bytes = stream.get_data()
                except Exception:
                    continue
                subtype = candidate
                file_count += 1
                embedded_stream_hashes.append(sha256_bytes(stream_bytes))

    if len(embedded_stream_hashes) == 1:
        embedded_stream_sha = embedded_stream_hashes[0]
    elif embedded_stream_hashes:
        embedded_stream_sha = sha256_bytes("\n".join(sorted(embedded_stream_hashes)).encode("utf-8"))
    else:
        embedded_stream_sha = None
    return {
        "present": file_count > 0,
        "subtype": subtype,
        "descriptorObjectCount": descriptor_count,
        "fileObjectCount": file_count,
        "embeddedStreamSha256": embedded_stream_sha,
    }


def inspect_pdf(pdf_bytes: bytes, font_sha: str, geometry: dict[str, Any], packages: tuple[Any, Any, Any, Any, dict[str, Any]]) -> dict[str, Any]:
    pdfplumber, pdf_reader, _pdfmetrics, _tt_font, reportlab_tools = packages
    reader = pdf_reader(BytesIO(pdf_bytes))
    extracted_pages: list[str] = []
    with pdfplumber.open(BytesIO(pdf_bytes)) as pdf:
        for page in pdf.pages:
            extracted_pages.append(page.extract_text() or "")
    extracted_text = normalize_extracted_text("\n".join(extracted_pages))

    metadata_findings: list[str] = []
    metadata = reader.metadata or {}
    for key, value in metadata.items():
        text = f"{key}: {value}"
        if any(pattern.search(text) for pattern in PRIVATE_METADATA_PATTERNS):
            metadata_findings.append(str(key))
    for pattern in PRIVATE_METADATA_PATTERNS:
        if pattern.search(extracted_text):
            metadata_findings.append("extractedText")
            break

    embedded_font = inspect_embedded_fonts(reader)
    embedded_font_sha = embedded_font["embeddedStreamSha256"] or "0" * 64

    root_counts = count_pdf_risks(reader.trailer.get("/Root", {}))
    page_counts = {"javascript": 0, "external": 0, "attachments": 0}
    for page in reader.pages:
        child_counts = count_pdf_risks(page)
        for key in page_counts:
            page_counts[key] += child_counts[key]

    return {
        "valid": True,
        "pageCount": len(reader.pages),
        "extractedText": extracted_text,
        "extractedTextSha256": sha256_bytes(extracted_text.encode("utf-8")),
        "configuredFontSha256": font_sha,
        "embeddedFontSha256": embedded_font_sha,
        "embeddedFont": embedded_font,
        "geometry": geometry,
        "encrypted": bool(reader.is_encrypted),
        "javascriptActionCount": root_counts["javascript"] + page_counts["javascript"],
        "attachmentCount": root_counts["attachments"] + page_counts["attachments"],
        "externalActionCount": root_counts["external"] + page_counts["external"],
        "privateMetadataFindings": sorted(metadata_findings),
        "visualAcceptance": {
            "status": "pending",
            "evidence": {
                "status": "not-run",
                "renderer": "poppler",
                "reason": "visual-renderer-not-invoked",
            },
        },
        "packageVersions": {
            "reportlab": reportlab_tools["reportlab"],
            "pdfplumber": reportlab_tools["pdfplumber"],
            "pypdf": reportlab_tools["pypdf"],
        },
    }


def main() -> None:
    try:
        payload = load_payload()
        font_path, font_sha = verify_font(payload.get("font", {}))
        packages = import_pdf_packages()
        pdf_bytes, geometry = render_pdf(payload, font_path, font_sha, packages)
        report = inspect_pdf(pdf_bytes, font_sha, geometry, packages)
    except PdfProviderError as error:
        fail(str(error))
    except Exception as error:
        fail(f"PDF не создан: непредвиденная ошибка ReportLab-поставщика: {error}.")

    print(json.dumps({
        "ok": True,
        "bytesBase64": base64.b64encode(pdf_bytes).decode("ascii"),
        "report": report,
    }, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
