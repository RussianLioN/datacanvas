#!/usr/bin/env node
import {
  materializeConsumerFromConfigPath,
  parseMaterializeConsumerArgs,
} from '../dist/generators/consumer-materialization.js';

try {
  const { configPath } = parseMaterializeConsumerArgs(process.argv.slice(2));
  const result = materializeConsumerFromConfigPath(process.cwd(), configPath);
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(`${message}\n`);
  process.exitCode = 1;
}
