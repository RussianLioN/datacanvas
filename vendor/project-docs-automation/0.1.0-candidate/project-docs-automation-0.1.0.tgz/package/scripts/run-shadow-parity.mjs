#!/usr/bin/env node
import { runReleaseBoundShadowParity, runShadowParity } from '../dist/parity/run-shadow-parity.js';

const valueFlags = new Set([
  '--profile',
  '--source-root',
  '--legacy-root',
  '--candidate-root',
  '--legacy-materialization',
  '--candidate-materialization',
  '--mode',
  '--consumer-root',
  '--consumer-pin',
  '--materialization-config',
]);

const deprecatedFlags = new Set(['--accepted-differences', '--structural-mapping']);

function failUsage(message) {
  console.error(message);
  process.exit(64);
}

function parseArgs(argv) {
  const parsed = new Map();
  for (let index = 0; index < argv.length; index += 1) {
    const flag = argv[index];
    if (deprecatedFlags.has(flag)) {
      failUsage(`Флаг ${flag} устарел и запрещен: закрепленные файлы берутся только из профиля, подмена путем запуска недопустима.`);
    }
    if (!valueFlags.has(flag)) {
      failUsage(`Неизвестный параметр запуска теневого паритета: ${flag}.`);
    }
    if (parsed.has(flag)) {
      failUsage(`Параметр ${flag} задан повторно.`);
    }
    const value = argv[index + 1];
    if (value === undefined || value.startsWith('--')) {
      failUsage(`Параметр ${flag} требует значение.`);
    }
    parsed.set(flag, value);
    index += 1;
  }
  return parsed;
}

function required(parsed, flag) {
  const value = parsed.get(flag);
  if (!value) failUsage(`Требуется ${flag}. Перед запуском выполните npm run build.`);
  return value;
}

const args = parseArgs(process.argv.slice(2));
const profilePath = required(args, '--profile');
const sourceRoot = required(args, '--source-root');
const mode = args.get('--mode') ?? 'preflight';

if (mode !== 'preflight' && mode !== 'release-bound') {
  failUsage('--mode должен быть preflight или release-bound.');
}

const consumerRoot = args.get('--consumer-root');
const consumerPin = args.get('--consumer-pin');
const materializationConfig = args.get('--materialization-config');
const preflightOnlyFlags = [
  '--legacy-root',
  '--candidate-root',
  '--legacy-materialization',
  '--candidate-materialization',
];

let evidence;
if (mode === 'release-bound') {
  const forbidden = preflightOnlyFlags.filter((flag) => args.has(flag));
  if (forbidden.length > 0) {
    failUsage(`Для --mode release-bound запрещены внешние корни и доказательства материализации: ${forbidden.join(', ')}.`);
  }
  if (!consumerRoot || !consumerPin || !materializationConfig) {
    failUsage('Для --mode release-bound требуются --consumer-root, --consumer-pin и --materialization-config.');
  }
  evidence = await runReleaseBoundShadowParity({
    profilePath,
    sourceRoot,
    consumerRoot,
    pinPath: consumerPin,
    materializationConfigPath: materializationConfig,
  });
} else {
  if (consumerRoot || consumerPin || materializationConfig) {
    failUsage('--consumer-root, --consumer-pin и --materialization-config допустимы только для --mode release-bound.');
  }
  evidence = await runShadowParity({
    profilePath,
    sourceRoot,
    legacyRoot: required(args, '--legacy-root'),
    candidateRoot: required(args, '--candidate-root'),
    legacyMaterializationPath: args.get('--legacy-materialization'),
    candidateMaterializationPath: args.get('--candidate-materialization'),
    releaseMode: 'preflight',
  });
}

process.stdout.write(JSON.stringify(evidence, null, 2) + '\n');
process.exit(evidence.exitCode);
