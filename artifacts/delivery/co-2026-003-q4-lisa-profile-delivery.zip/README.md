# Пакет поставки CO-2026-003: чистовой браузерный прототип заказа презентации

Локальный архив главной цепочки документации. Все ссылки относительные и работают после распаковки.

## 1. Принятое продуктовое решение


## 2. Карта бизнес-утверждений CO


## 3. Vision — видение продукта

- [docs/product-vision.md](repository/docs/product-vision.md)

## 4. BMC — бизнес-модель продукта

- [docs/product/bmc/bmc-v0.2.md](repository/docs/product/bmc/bmc-v0.2.md)

## 5. Пользовательские истории

- [docs/product/requirements/user-stories.md](repository/docs/product/requirements/user-stories.md)

## 6. Бизнес-требования

- [docs/product/requirements/business-requirements.md](repository/docs/product/requirements/business-requirements.md)

## 7. Нефункциональные требования


## 8. Критерии приемки


## 9. Product backlog — продуктовый список работ


## 10. XLSX backlog и оценка ресурсов


## 11. Roadmap — дорожная карта


## 12. Продуктовые гипотезы


## 13. Системный анализ и спецификации


## 14. Планирование спринтов и Jira package


## 15. Traceability — трассируемость


## 16. Confluence и экспортный пакет


## 17. Evidence и завершение запуска


## Дополнительные материалы

- [Граница реализации 2026 года](repository/docs/product/sources/co-2026-003-current-2026-scope.md)
- [Машиночитаемая граница реализации 2026 года](repository/docs/product/sources/co-2026-003-current-2026-scope.json)
- [Происхождение очищенной рабочей книги 2026-08-19](repository/docs/product/sources/working/datacanvas-backlog-draft-pshe-2026-08-19.provenance.json)
- [Заявка на изменение Q4_2026](repository/docs/product/change-orders/co-2026-003-q4-lisa-profile.md)
- [Реестр согласованных решений интервью](repository/docs/product/change-orders/co-2026-003-authoritative-interview-decision-register.md)
- [Реестр выбранных текстов прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/owner-approved-texts.md)
- [Машиночитаемый источник выбранных текстов прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/owner-approved-texts.json)
- [Реестр разрешений и приёмок выпуска](repository/docs/product/change-orders/co-2026-003-release-approval-ledger.md)
- [Машиночитаемый реестр разрешений и приёмок выпуска](repository/docs/product/change-orders/co-2026-003-release-approval-ledger.json)
- [Очищенные данные справки ООО «Водолей Трейд»](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/client-reference-data.json)
- [Описание чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/README.md)
- [Локальная стартовая страница браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/index.html)
- [Логика браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/app.js)
- [Модель экранов браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/data.js)
- [Стили браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/styles.css)
- [Манифест состава браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/manifest.json)
- [Шрифт браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/NotoSans[wdth,wght].ttf)
- [Векторный экран письма](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-email.svg)
- [SlideDoc: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-1.png)
- [SlideDoc: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-2.png)
- [SlideDoc: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-3.png)
- [Sber 2025: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-1.png)
- [Sber 2025: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-2.png)
- [Sber 2025: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-3.png)
- [MAG: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-1.png)
- [MAG: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-2.png)
- [MAG: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-3.png)
- [Договор чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/browser-native-phone-prototype-contract.json)
- [Итоговое решение владельца по браузерному прототипу](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/owner-final-approval.json)
- [Решение владельца по внешней 4K-серии](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/external-4k-series-owner-approval.json)
- [Манифест набора спецификаций Q4_2026](repository/docs/product/specs/generated-spec-package-manifest.json)
- [Спецификация адресов и почтовой доставки Q4_2026](repository/docs/product/specs/feature-spec-q4-profile-mail.json)
- [Спецификация состояния заказа в Лисе Q4_2026](repository/docs/product/specs/feature-spec-q4-lisa-states.json)
- [Задача получения адресов Q4_2026](repository/docs/product/specs/task-spec-q4-profile-addresses.json)
- [Задача почтовой доставки Q4_2026](repository/docs/product/specs/task-spec-q4-profile-mail-delivery.json)
- [Задача принятия заказа в Лисе Q4_2026](repository/docs/product/specs/task-spec-q4-lisa-order-state.json)
- [Задача статусов в Лисе Q4_2026](repository/docs/product/specs/task-spec-q4-lisa-status-state.json)
- [Отчёт доказательств чистового браузерного прототипа](repository/docs/release/co-2026-003-browser-native-phone-prototype-release-evidence.md)
- [Машиночитаемое доказательство чистового браузерного прототипа](repository/docs/release/co-2026-003-browser-native-phone-prototype-release-evidence.json)
