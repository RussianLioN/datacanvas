# Пакет поставки CO-2026-003: чистовой браузерный прототип заказа презентации

Локальный архив главной цепочки документации. Все ссылки относительные и работают после распаковки.

## 1. Принятое продуктовое решение

- [docs/product/change-orders/co-2026-001-a2a-first-priority.md](repository/docs/product/change-orders/co-2026-001-a2a-first-priority.md)
- [docs/product/change-orders/co-2026-002-agent-launch-delivery-scope.md](repository/docs/product/change-orders/co-2026-002-agent-launch-delivery-scope.md)

## 2. Карта бизнес-утверждений CO

- [docs/product/requirements/business-claim-map.json](repository/docs/product/requirements/business-claim-map.json)

## 3. Vision — видение продукта

- [docs/product-vision.md](repository/docs/product-vision.md)

## 4. BMC — бизнес-модель продукта

- [docs/product/bmc/bmc-v0.2.md](repository/docs/product/bmc/bmc-v0.2.md)

## 5. Пользовательские истории

- [docs/product/requirements/user-stories.md](repository/docs/product/requirements/user-stories.md)

## 6. Бизнес-требования

- [docs/product/requirements/business-requirements.md](repository/docs/product/requirements/business-requirements.md)

## 7. Нефункциональные требования

- [docs/product/requirements/non-functional-requirements.md](repository/docs/product/requirements/non-functional-requirements.md)

## 8. Критерии приемки

- [docs/product/requirements/acceptance-criteria.md](repository/docs/product/requirements/acceptance-criteria.md)

## 9. Product backlog — продуктовый список работ

- [docs/product/backlog/product-backlog.md](repository/docs/product/backlog/product-backlog.md)

## 10. XLSX backlog и оценка ресурсов


## 11. Roadmap — дорожная карта

- [docs/product/roadmap/roadmap-v0.1.md](repository/docs/product/roadmap/roadmap-v0.1.md)

## 12. Продуктовые гипотезы

- [docs/product/hypotheses/hypothesis-board.md](repository/docs/product/hypotheses/hypothesis-board.md)

## 13. Системный анализ и спецификации

- [docs/architecture/system-analysis/sa-spec.json](repository/docs/architecture/system-analysis/sa-spec.json)
- [docs/architecture/system-analysis/srs-v0.1.json](repository/docs/architecture/system-analysis/srs-v0.1.json)

## 14. Планирование спринтов и Jira package

- [docs/product/analysis/documentation-consistency-audit/sprint-candidate-plan.md](repository/docs/product/analysis/documentation-consistency-audit/sprint-candidate-plan.md)

## 15. Traceability — трассируемость


## 16. Confluence и экспортный пакет

- [docs/product/analysis/documentation-consistency-audit/confluence-import-map.md](repository/docs/product/analysis/documentation-consistency-audit/confluence-import-map.md)

## 17. Evidence и завершение запуска

- [docs/process/cascading-governance/impact-analysis-report.json](repository/docs/process/cascading-governance/impact-analysis-report.json)

## Дополнительные материалы

- [Очищенная рабочая книга с актуальными сроками и ресурсами 2026-08-17](repository/docs/product/sources/working/datacanvas-backlog-draft-pshe-2026-08-17.xlsx)
- [Происхождение очищенной рабочей книги 2026-08-17](repository/docs/product/sources/working/datacanvas-backlog-draft-pshe-2026-08-17.provenance.json)
- [Заявка на изменение Q4_2026](repository/docs/product/change-orders/co-2026-003-q4-lisa-profile.md)
- [Реестр согласованных решений интервью](repository/docs/product/change-orders/co-2026-003-authoritative-interview-decision-register.md)
- [Реестр выбранных текстов будущего прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/owner-approved-texts.md)
- [Машиночитаемый реестр выбранных текстов будущего прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/owner-approved-texts.json)
- [Карта влияния изменения](repository/docs/product/change-orders/co-2026-003-q4-lisa-profile-impact.md)
- [Текущий реестр разрешений и приёмок выпуска CO-2026-003](repository/docs/product/change-orders/co-2026-003-release-approval-ledger.md)
- [Машиночитаемый реестр разрешений и приёмок выпуска CO-2026-003](repository/docs/product/change-orders/co-2026-003-release-approval-ledger.json)
- [Путь пользователя в Лисе](repository/docs/product/analysis/presentation-link-lisa-user-journey/user-journey.md)
- [Исходный договор пути пользователя](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/journey-contract.json)
- [Договор изготовления визуальных экранов из SVG-источников](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/visual-components-contract.json)
- [Договор поэкранной подготовки и приёмки канонических SVG](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/canonical-svg-frame-pipeline-contract.md)
- [Машиночитаемый договор поэкранной подготовки и приёмки канонических SVG](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/canonical-svg-frame-pipeline-contract.json)
- [Реестр PDF-доноров вариантов презентации ООО «Водолей Трейд»](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/presentation-pdf-donor-register.json)
- [Очищенные данные справки ООО «Водолей Трейд» для замены в SVG](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/client-reference-data.json)
- [Кандидат обновления прототипа и состояние поэкранной приёмки](repository/docs/product/analysis/presentation-link-lisa-user-journey/prototype-revision-candidate.md)
- [Машиночитаемое состояние кандидата обновления прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/prototype-revision-candidate.json)
- [Разбор причины неполного каскадного обновления дополнений CO-2026-003](repository/docs/knowledge/rca/2026-08-25-co-2026-003-amendment-cascade-drift.md)
- [Разбор причины недостаточного разрешения внешних экранов браузерного прототипа](repository/docs/knowledge/rca/2026-09-03-browser-native-phone-external-asset-resolution.md)
- [Разбор причины рассинхронизации статуса чистового выпуска и его проверок](repository/docs/knowledge/rca/2026-09-03-browser-final-acceptance-gate-drift.md)
- [План поэтапной отрисовки и приёмки SVG-прототипа](repository/docs/plans/co-2026-003-svg-prototype-revision-implementation-plan.md)
- [Описание чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/README.md)
- [Открыть чистовой браузерный прототип](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/index.html)
- [Логика чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/app.js)
- [Модель экранов чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/data.js)
- [Стили чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/styles.css)
- [Манифест состава и целостности чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/manifest.json)
- [Шрифт чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/NotoSans[wdth,wght].ttf)
- [Векторный экран письма](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-email.svg)
- [SlideDoc: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-1.png)
- [SlideDoc: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-2.png)
- [SlideDoc: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-slidedoc-page-3.png)
- [Sber 2025: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-1.png)
- [Sber 2025: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-2.png)
- [Sber 2025: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-sber2025-page-3.png)
- [MAG: страница 1 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-1.png)
- [MAG: страница 2 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-2.png)
- [MAG: страница 3 в 4K](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/assets/external/lisa-presentation-mag-page-3.png)
- [Манифест принятой серии внешних 4K-экранов](repository/docs/product/analysis/presentation-link-lisa-user-journey/candidate-evidence/browser-native-phone-prototype/external-4k-series-review/series-manifest.json)
- [Договор чистового браузерного прототипа](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/browser-native-phone-prototype-contract.json)
- [Итоговое решение владельца по чистовому прототипу](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/owner-final-approval.json)
- [Решение владельца по внешней 4K-серии](repository/docs/product/analysis/presentation-link-lisa-user-journey/source/browser-native-phone-prototype/external-4k-series-owner-approval.json)
- [Манифест набора спецификаций Q4_2026](repository/docs/product/specs/generated-spec-package-manifest.json)
- [Спецификация адресов и почтовой доставки Q4_2026](repository/docs/product/specs/feature-spec-q4-profile-mail.json)
- [Спецификация состояния заказа в Лисе Q4_2026](repository/docs/product/specs/feature-spec-q4-lisa-states.json)
- [Задача получения адресов Q4_2026](repository/docs/product/specs/task-spec-q4-profile-addresses.json)
- [Задача почтовой доставки Q4_2026](repository/docs/product/specs/task-spec-q4-profile-mail-delivery.json)
- [Задача принятия заказа в Лисе Q4_2026](repository/docs/product/specs/task-spec-q4-lisa-order-state.json)
- [Задача статусов в Лисе Q4_2026](repository/docs/product/specs/task-spec-q4-lisa-status-state.json)
- [Инструкция агенту для получения адресов Q4_2026](repository/docs/product/specs/agent-prompt-spec-q4-profile-addresses.json)
- [Инструкция агенту для почтовой доставки Q4_2026](repository/docs/product/specs/agent-prompt-spec-q4-profile-mail-delivery.json)
- [Инструкция агенту для принятия заказа Q4_2026](repository/docs/product/specs/agent-prompt-spec-q4-lisa-order-state.json)
- [Инструкция агенту для статусов Q4_2026](repository/docs/product/specs/agent-prompt-spec-q4-lisa-status-state.json)
- [Отчёт доказательств чистового браузерного прототипа](repository/docs/release/co-2026-003-browser-native-phone-prototype-release-evidence.md)
- [Машиночитаемое доказательство чистового браузерного прототипа](repository/docs/release/co-2026-003-browser-native-phone-prototype-release-evidence.json)
