# Главная цепочка документации DataCanvas

Локальный архив главной цепочки документации. Все ссылки относительные и работают после распаковки.

## 1. Принятое продуктовое решение

- [docs/product/change-orders/co-2026-001-a2a-first-priority.md](repository/docs/product/change-orders/co-2026-001-a2a-first-priority.md)
- [docs/product/change-orders/co-2026-002-agent-launch-delivery-scope.md](repository/docs/product/change-orders/co-2026-002-agent-launch-delivery-scope.md)

## 2. Карта бизнес-утверждений CO

- [docs/product/requirements/business-claim-map.json](repository/docs/product/requirements/business-claim-map.json)

## 3. Vision — видение продукта

- [docs/product-vision.md](repository/docs/product-vision.md)

## 4. BMC — бизнес-модель продукта

- [docs/product/bmc/bmc-v0.2.md](repository/docs/product/bmc/bmc-v0.2.md)

## 5. Пользовательские истории

- [docs/product/requirements/user-stories.md](repository/docs/product/requirements/user-stories.md)

## 6. Бизнес-требования

- [docs/product/requirements/business-requirements.md](repository/docs/product/requirements/business-requirements.md)

## 7. Нефункциональные требования

- [docs/product/requirements/non-functional-requirements.md](repository/docs/product/requirements/non-functional-requirements.md)

## 8. Критерии приемки

- [docs/product/requirements/acceptance-criteria.md](repository/docs/product/requirements/acceptance-criteria.md)

## 9. Product backlog — продуктовый список работ

- [docs/product/backlog/product-backlog.md](repository/docs/product/backlog/product-backlog.md)

## 10. XLSX backlog и оценка ресурсов

- [docs/product/sources/working/datacanvas-backlog-draft-pshe-2026-07-08.xlsx](repository/docs/product/sources/working/datacanvas-backlog-draft-pshe-2026-07-08.xlsx)

## 11. Roadmap — дорожная карта

- [docs/product/roadmap/roadmap-v0.1.md](repository/docs/product/roadmap/roadmap-v0.1.md)

## 12. Продуктовые гипотезы

- [docs/product/hypotheses/hypothesis-board.md](repository/docs/product/hypotheses/hypothesis-board.md)

## 13. Системный анализ и спецификации

- [docs/architecture/system-analysis/sa-spec.json](repository/docs/architecture/system-analysis/sa-spec.json)
- [docs/architecture/system-analysis/srs-v0.1.json](repository/docs/architecture/system-analysis/srs-v0.1.json)

## 14. Планирование спринтов и Jira package

- [docs/product/analysis/documentation-consistency-audit/sprint-candidate-plan.md](repository/docs/product/analysis/documentation-consistency-audit/sprint-candidate-plan.md)

## 15. Traceability — трассируемость

- [docs/product/requirements/traceability-matrix.json](repository/docs/product/requirements/traceability-matrix.json)

## 16. Confluence и экспортный пакет

- [docs/product/analysis/documentation-consistency-audit/confluence-import-map.md](repository/docs/product/analysis/documentation-consistency-audit/confluence-import-map.md)

## 17. Evidence и завершение запуска

- [docs/process/cascading-governance/impact-analysis-report.json](repository/docs/process/cascading-governance/impact-analysis-report.json)

## Дополнительные материалы

- [BMC — исходное представление PlantUML](repository/docs/product/bmc/source/derived/datacanvas-bmc.puml)
- [BMC — векторное представление SVG](repository/docs/product/bmc/source/derived/datacanvas-bmc.svg)
- [BMC — растровое представление PNG](repository/docs/product/bmc/source/derived/datacanvas-bmc.png)
- [BMC — представление PDF](repository/docs/product/bmc/source/derived/datacanvas-bmc.pdf)
- [Выгрузка кандидатных историй бэклога CSV](repository/docs/product/backlog/agent-launch-candidate-stories-2026-q3.csv)
- [Контролируемый очищенный XLSX-источник](repository/docs/product/sources/reference/datacanvas-backlog-source-sanitized.xlsx)
- [Руководство по массовому импорту пользовательских историй DataCanvas в Jira](repository/docs/process/guides/datacanvas-jira-story-bulk-import.md)
- [Подготовленный CSV для импорта пользовательских историй DataCanvas в Jira](repository/artifacts/generated/jira/datacanvas-stories-2026-q4.csv)
