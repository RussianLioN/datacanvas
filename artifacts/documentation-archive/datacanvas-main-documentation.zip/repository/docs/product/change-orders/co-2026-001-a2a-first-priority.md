# CO-2026-001: Приоритет Запуска DataCanvas Другим Агентом

Навигация: [DataCanvas](../../../README.md) / [Документация](../../README.md) / [Продукт](../README.md) / [Product Change Orders](README.md) / CO-2026-001

Статус: accepted
Владелец: Product Owner
Проверка: `npm run validate:product-change-orders`

## Причина

Запуск DataCanvas другим агентом не является простой перестановкой backlog. Он меняет первый продуктовый маршрут запуска, доверительную границу входных данных, правила проверки входа, статусы обработки, обратный вызов, трассировку и будущую проверку качества.

В пользовательских и стейкхолдерских текстах используется формулировка "другой агент". Техническое обозначение `A2A` допустимо только в технических артефактах, схемах, контрактах и проверках, где точное имя протокола важно.

## Изменение Приоритета

| Было | Стало |
|---|---|
| Запуск через Лису, запуск другим агентом | Запуск другим агентом, запуск через Лису |

## Статус Решения

Product Owner decision: `accepted`.

Канонический продуктовый приоритет меняется: первым направлением становится запуск DataCanvas другим агентом, вторым - запрос пользователя на подготовку презентации через Лису.

## Продуктовые Правила

- Если задача пришла от другого агента и данных достаточно, DataCanvas сразу готовит презентацию и запускает доставку файла по электронной почте.
- Пользовательское подтверждение, просмотр структуры будущей презентации, правки до генерации и уточняющие вопросы относятся к диалоговому режиму в Лисе.
- Итоговая презентация должна доставляться в редактируемом формате, чтобы пользователь мог самостоятельно и оперативно внести правки.
- Ёмкость, ресурсы и вытеснение существующих stories остаются открытыми до отдельной оценки.
- Этот репозиторий ведёт проектную документацию и документальное сопровождение; фактическая реализация и разработка ведутся вне этого проекта.

## Согласованные Артефакты

- `docs/product-vision.md`
- `docs/product/requirements/user-stories.md`
- `docs/product/backlog/agent-launch-candidate-stories-2026-q3.md`
- `docs/product/backlog/agent-launch-candidate-stories-2026-q3.csv`
- `docs/product/bmc/bmc-v0.2.md`
- `docs/product/requirements/business-requirements.md`
- `docs/product/requirements/acceptance-criteria.md`
- `docs/product/requirements/traceability-matrix.json`
- `docs/architecture/system-analysis/datacanvas-lifecycle-state-model.md`
- `docs/architecture/system-analysis/srs-v0.1.md`
- `docs/product/revisions/co-2026-001-source-revision/revision-ledger.md`
- `docs/product/sources/product-source-registry.json`
- `docs/product/change-orders/co-2026-001-acceptance-questionnaire-state.json`
- `docs/product/change-orders/co-2026-001-acceptance-questionnaire-log.md`

## Проверка

```bash
npm run validate:product-change-orders
npm run validate:change-impact
npm run validate:co-questionnaire
```
